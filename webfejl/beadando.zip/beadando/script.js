function updateLevelRange(val) {
    document.getElementById('levelValue').innerHTML = val;
  }