#include "menu.h"

int main()
{
    Menu m;
    m.run();
    return 0;
}
