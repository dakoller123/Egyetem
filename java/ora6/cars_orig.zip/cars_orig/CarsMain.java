import car.Car;

import java.util.ArrayList;
import java.util.List;

public class CarsMain {

    public static void main(String[] args){
        List<Car> cars = loadCars(args[0]);
        for (Car car : cars) {
            System.out.println(car);
        }
    }

    private static List<Car> loadCars(String path) {
        List<Car> cars = new ArrayList<>(); 
        // TODO: implement reading of Car records from file
        // cars.add(new Car(...));
        return cars;
    }

}